"""Read-only next-batch fingerprints and isolated continuation probes."""

import copy
import hashlib
import io
from types import SimpleNamespace

import numpy as np
import torch
from ad2_train import BatchOrder, PilotTrainer, capture_rng_state, restore_rng_state


def equal(a, b):
    if isinstance(a, torch.Tensor):
        return torch.equal(a, b)
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)):
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b, strict=True))
    return a == b


def generator(state):
    result = torch.Generator()
    result.set_state(state.cpu())
    return result


def order_clone(trainer):
    result = BatchOrder(len(trainer.data), 8, trainer.seed + 1)
    result.load_state_dict(copy.deepcopy(trainer.order.state_dict()))
    return result


def update_hash(h, name, value):
    a = value.detach().cpu().contiguous().numpy()
    h.update(f"{name}:{a.dtype}:{a.shape}:".encode())
    h.update(memoryview(a).cast("B"))


def preview(trainer):
    if trainer.step >= trainer.end:
        return None
    trainer.assert_streams()
    ids = order_clone(trainer).next()
    variant = (trainer.step // trainer.per_pass) % 4
    state = trainer.transform_rng.get_state()
    p0 = SimpleNamespace(
        config=trainer.config, device=trainer.device, transform_rng=generator(state)
    )
    p1 = SimpleNamespace(
        config=trainer.config, device=trainer.device, transform_rng=generator(state)
    )
    pixels = trainer.pixels[ids]
    views, _ = PilotTrainer.paired_views(p0, pixels)
    local, _ = PilotTrainer.paired_views(p1, trainer.changed[ids, variant])
    identity = torch.cat((pixels, pixels))
    normalize = trainer.baselines["B1"].normalize
    inputs = hashlib.sha256()
    features = hashlib.sha256()
    trainer.encoder.clear()
    for name, raw in [("B0", identity), ("B1", views), ("local", local)]:
        normalized = normalize(raw)
        f, _ = trainer.encoder.embed(normalized)
        update_hash(inputs, name, normalized)
        update_hash(features, name, f)
    mask = (views - local).abs().amax(dim=1) > 1 / 255
    mask = mask.reshape(2, len(ids), 32, 8, 32, 8).any(dim=(3, 5)).reshape(2, -1)
    noise = (
        torch.randn((2 * len(ids) * 1024, 1536), generator=generator(trainer.noise_rng.get_state()))
        * 0.015
    )
    extra = hashlib.sha256()
    update_hash(extra, "mask", mask)
    update_hash(extra, "noise", noise)
    trainer.assert_streams()
    return {
        "ids": ids,
        "variant": variant,
        "normalized_inputs_sha256": inputs.hexdigest(),
        "frozen_features_sha256": features.hexdigest(),
        "mask_noise_sha256": extra.hexdigest(),
    }


def fork(trainer):
    clone = copy.copy(trainer)
    clone.models, clone.opts = copy.deepcopy((trainer.models, trainer.opts))
    clone.order = order_clone(trainer)
    clone.transform_rng = generator(trainer.transform_rng.get_state())
    clone.noise_rng = generator(trainer.noise_rng.get_state())
    clone.baselines = {}
    for arm, original in trainer.baselines.items():
        value = copy.copy(original)
        value.backend = SimpleNamespace(
            adapter=clone.models[arm][0],
            discriminator=clone.models[arm][1],
            encoder=trainer.encoder.raw.encoder,
            encoder_hash=trainer.encoder.raw.encoder_hash,
            embed=trainer.encoder.embed,
        )
        value.adapter_opt, value.discriminator_opt = clone.opts[arm]
        value.order = order_clone(trainer)
        value.transform_rng = generator(trainer.transform_rng.get_state())
        value.noise_rng = generator(trainer.noise_rng.get_state())
        clone.baselines[arm] = value
    return clone


def check_resume(trainer, protocol_sha256):
    before = trainer.state(protocol_sha256)
    global_state = capture_rng_state(cuda=True)
    stream = io.BytesIO()
    torch.save(before, stream)
    restored_state = torch.load(
        io.BytesIO(stream.getvalue()), map_location="cpu", weights_only=True
    )
    reference = fork(trainer)
    restored = fork(trainer)
    try:
        reference_value = reference.train_step()
        reference_state = reference.state(protocol_sha256)
        restored.restore(restored_state, protocol_sha256)
        restored_value = restored.train_step()
        actual = restored.state(protocol_sha256)
        for key in ["models", "optimizers", "order", "transform_rng", "noise_rng", "rng"]:
            if not equal(reference_state[key], actual[key]):
                raise ValueError("serialized next actual update differs: " + key)
        for key in reference_value:
            if (
                not key.startswith("embedding_cache_")
                and reference_value[key] != restored_value[key]
            ):
                raise ValueError("next-step losses/inputs differ: " + key)
    finally:
        restore_rng_state(global_state)
        trainer.encoder.clear()
    after = trainer.state(protocol_sha256)
    for key in ["models", "optimizers", "order", "transform_rng", "noise_rng", "rng"]:
        if not equal(before[key], after[key]):
            raise ValueError("probe changed live training: " + key)
    return {
        "passed": True,
        "all7_heads_next_actual_batch_parameters_buffers_optimizers_rng_bit_exact": True,
        "live_model_and_streams_unchanged": True,
        "scope": "continuation mechanics, no evaluation inputs",
    }


@torch.no_grad()
def calibrate(trainer, validation):
    for nets in trainer.models.values():
        for net in nets:
            net.eval()
    patches = {a: [] for a in trainer.arms}
    row_ids = []
    normalize = trainer.baselines["B1"].normalize
    for sample in validation:
        image = sample["image"]
        pixels = (
            torch.from_numpy(np.array(image, copy=True))[None]
            .permute(0, 3, 1, 2)
            .contiguous()
            .to(trainer.device)
        )
        trainer.encoder.clear()
        f, _ = trainer.encoder.embed(normalize(pixels))
        if f.shape != (1024, 1536):
            raise ValueError("single-view calibration grid differs")
        for arm, (a, d) in trainer.models.items():
            p = (-d(a(f))).reshape(1024).cpu().numpy()
            if not np.isfinite(p).all():
                raise ValueError("nonfinite calibration score")
            patches[arm].append(p)
        row_ids.append(sample["image_id"])
    arrays = {a: np.stack(value) for a, value in patches.items()}
    metrics = {
        a: {
            "threshold": float(np.quantile(value.max(axis=1), 0.95, method="higher")),
            "normal_patch_std": float(value.std()),
            "normal_validation_images": len(value),
        }
        for a, value in arrays.items()
    }
    return metrics, arrays, row_ids
