"""Exact original baseline steps, shared frozen embeddings and fixed local synthesis."""

# Resolve the private experiment modules before importing the shared package.
# ruff: noqa: E402

import copy
import hashlib
import io
import math
import sys
import zipfile
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [
    str(ROOT / "src"),
    str(HERE.parent / "routed-consistency-20261115"),
    str(HERE.parent / "local-global-synthesis-20261115"),
    str(HERE.parent / "gradient-synthesis-20261115"),
]
import local_global_study as recipe
import routed_model
from ad2_losses import pure_objective

from lc_simplenet.data import NormalRecord
from lc_simplenet.pilot import (
    BatchOrder,
    PilotConfig,
    PilotTrainer,
    UpstreamBackend,
    seed_runtime,
    state_hash,
)
from lc_simplenet.provenance import capture_rng_state, restore_rng_state


def cpu(value):
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {k: cpu(v) for k, v in value.items()}
    if isinstance(value, list):
        return [cpu(v) for v in value]
    if isinstance(value, tuple):
        return tuple(cpu(v) for v in value)
    return value


class StagedDataset:
    def __init__(self, archive, metadata, split):
        self.dataset, self.category, self.split = "mvtec_ad2", metadata["category"], split
        self.manifest_sha256, self.output_size = metadata["manifest_sha256"], (256, 256)
        rows = [r for r in metadata["rows"] if r["split"] == split]
        self.records = tuple(
            NormalRecord(**{k: r[k] for k in NormalRecord.__dataclass_fields__}) for r in rows
        )
        self.images = []
        with zipfile.ZipFile(archive) as z:
            for row in rows:
                raw = z.read(row["image_id"])
                if hashlib.sha256(raw).hexdigest() != row["sha256"]:
                    raise ValueError("staged source changed")
                with Image.open(io.BytesIO(raw)) as image:
                    if image.mode != "RGB" or image.size != (256, 256):
                        raise ValueError("staged geometry differs")
                    pixels = np.asarray(image).copy()
                if hashlib.sha256(pixels.tobytes()).hexdigest() != row["resized_rgb_sha256"]:
                    raise ValueError("staged pixels changed")
                self.images.append(pixels.astype(np.float32) / np.float32(255))
        if len(self.images) != metadata["counts"][split]:
            raise ValueError("source population differs")

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        record = self.records[index]
        return {
            "image": self.images[index].copy(),
            "image_id": record.image_id,
            "dataset": self.dataset,
            "category": self.category,
            "split": self.split,
            "label": 0,
            "original_size": np.array([record.height, record.width], dtype=np.int64),
            "image_size": np.array([256, 256], dtype=np.int64),
        }


class SharedEncoder:
    def __init__(self, config, device):
        seed_runtime(config.seed)
        self.raw = UpstreamBackend(config, torch.device(device))
        self.cache = []
        self.hits = 0
        self.misses = 0

    def clear(self):
        self.cache.clear()

    def embed(self, pixels):
        if pixels.requires_grad:
            raise ValueError("frozen encoder input must not need gradients")
        for previous, result in self.cache:
            if previous.shape == pixels.shape and torch.equal(previous, pixels):
                self.hits += 1
                return result
        result = self.raw.embed(pixels)
        if result[0].requires_grad:
            raise ValueError("frozen embeddings acquired a graph")
        self.cache.append((pixels.detach().clone(), result))
        self.misses += 1
        return result

    def proxy(self, config, device):
        return SimpleNamespace(
            adapter=copy.deepcopy(self.raw.adapter),
            discriminator=copy.deepcopy(self.raw.discriminator),
            encoder=self.raw.encoder,
            encoder_hash=self.raw.encoder_hash,
            embed=self.embed,
        )


def config_for(metadata, seed, variant="B1", batch=8):
    return PilotConfig(
        "mvtec_ad2",
        metadata["category"],
        metadata["manifest_sha256"],
        variant=variant,
        lambda_score=0.1 if variant == "B2" else 0.0,
        seed=seed,
        batch_size=batch,
        image_size=(256, 256),
        brightness=(0.8, 1.2),
        gamma=(0.8, 1.2),
    )


class Trainer:
    def __init__(self, data, metadata, textures, seed, primary, device="cuda"):
        if primary not in ["L3", "R0", "R1", "R2", "P0", "P1"]:
            raise ValueError("undeclared source-selected method")
        self.data, self.metadata, self.seed, self.primary = data, metadata, seed, primary
        self.device = torch.device(device)
        self.config = config_for(metadata, seed)
        self.encoder = SharedEncoder(self.config, self.device)
        self.baselines = {
            a: PilotTrainer(
                config_for(metadata, seed, a), data, self.device, backend_factory=self.encoder.proxy
            )
            for a in ["B0", "B1", "B2"]
        }
        self.arms = ["B0", "B1", "B2", "L0", "L1", "L2", primary]
        self.models = {
            a: (t.backend.adapter, t.backend.discriminator) for a, t in self.baselines.items()
        }
        self.models.update(
            {
                a: (
                    copy.deepcopy(self.encoder.raw.adapter),
                    copy.deepcopy(self.encoder.raw.discriminator),
                )
                for a in self.arms[3:]
            }
        )
        self.opts = {a: (t.adapter_opt, t.discriminator_opt) for a, t in self.baselines.items()}
        self.opts.update(
            {a: recipe.optimizers(*self.models[a], recipe.POLICY) for a in self.arms[3:]}
        )
        initial = [state_hash(n.state_dict()) for n in self.models["B0"]]
        if any([state_hash(n.state_dict()) for n in m] != initial for m in self.models.values()):
            raise ValueError("control initialization differs")
        self.initial_sha256 = initial
        self.order = BatchOrder(len(data), 8, seed + 1)
        self.transform_rng = torch.Generator().manual_seed(seed + 2)
        self.noise_rng = torch.Generator().manual_seed(seed + 3)
        self.step = 0
        self.per_pass = math.ceil(len(data) / 8)
        self.end = 80 * self.per_pass
        self.pixels = (
            torch.from_numpy(np.stack(data.images)).permute(0, 3, 1, 2).contiguous().to(self.device)
        )
        self.changed = torch.empty((len(data), 4, 3, 256, 256), device=self.device)
        local_hash = hashlib.sha256()
        for i, row in enumerate(data.records):
            for v in range(4):
                key = "local-global-synthesis-v1:" + row.image_id + ":" + str(v)
                j = int(hashlib.sha256(("texture:" + key).encode()).hexdigest(), 16) % len(textures)
                changed, _ = recipe.synthesize(data.images[i], textures[j], key)
                local_hash.update(memoryview(changed).cast("B"))
                self.changed[i, v] = torch.from_numpy(changed).permute(2, 0, 1).to(self.device)
        self.local_variant_sha256 = local_hash.hexdigest()

    def _pairs(self, ids, variant, transform_state=None):
        if transform_state is None:
            transform_state = self.transform_rng.get_state()
        rng = torch.Generator()
        rng.set_state(transform_state)
        views, clipped = PilotTrainer.paired_views(self, self.pixels[ids])
        proxy = SimpleNamespace(config=self.config, transform_rng=rng, device=self.device)
        local, _ = PilotTrainer.paired_views(proxy, self.changed[ids, variant])
        if not torch.equal(rng.get_state(), self.transform_rng.get_state()):
            raise ValueError("local and normal lighting draws differ")
        return views, local, clipped

    def train_step(self):
        self.encoder.clear()
        values = {a: t.train_step() for a, t in self.baselines.items()}
        ids = self.order.next()
        variant = (self.step // self.per_pass) % 4
        views, local, clipped = self._pairs(ids, variant)
        normalize = self.baselines["B1"].normalize
        normal_features, _ = self.encoder.embed(normalize(views))
        local_features, _ = self.encoder.embed(normalize(local))
        clean, shifted = normal_features.chunk(2)
        c0, c1 = local_features.chunk(2)
        support = (views - local).abs().amax(dim=1) > 1 / 255
        masks = support.reshape(2, len(ids), 32, 8, 32, 8).any(dim=(3, 5)).reshape(2, -1)
        noise = (torch.randn((2 * len(clean), 1536), generator=self.noise_rng) * 0.015).to(
            self.device
        )
        for arm in self.arms[3:]:
            a, d = self.models[arm]
            a.train()
            d.train()
            for opt in self.opts[arm]:
                opt.zero_grad(set_to_none=True)
            if arm.startswith("P"):
                terms = pure_objective(
                    a,
                    d,
                    clean,
                    shifted,
                    noise,
                    inference_normalization=arm == "P1",
                    lambda_score=0.1,
                )
            elif arm.startswith("R"):
                terms = routed_model.objective(
                    a,
                    d,
                    clean,
                    shifted,
                    c0,
                    c1,
                    noise,
                    masks,
                    route_normal=arm != "R2",
                    use_lift=arm != "R0",
                )
            else:
                identity = arm == "L0"
                terms = recipe.objective(
                    a,
                    d,
                    clean,
                    clean if identity else shifted,
                    c0,
                    c0 if identity else c1,
                    noise,
                    masks[[0, 0]] if identity else masks,
                    lambda_normal=0.1 if arm in ["L2", "L3"] else 0.0,
                    lambda_lift=0.1 if arm == "L3" else 0.0,
                )
            if not all(torch.isfinite(v) for v in terms.values()):
                raise FloatingPointError("nonfinite objective: " + arm)
            terms["total"].backward()
            if any(
                not torch.isfinite(p.grad).all()
                for n in (a, d)
                for p in n.parameters()
                if p.grad is not None
            ):
                raise FloatingPointError("nonfinite gradient: " + arm)
            for opt in self.opts[arm]:
                opt.step()
            values[arm] = {k: float(v.detach()) for k, v in terms.items()}
        self.step += 1
        self.assert_streams()
        return {
            "step": self.step,
            "batch": len(ids),
            "epoch": self.order.epoch,
            "newly_clipped_fraction": clipped,
            "losses": values,
            "embedding_cache_hits": self.encoder.hits,
            "embedding_cache_misses": self.encoder.misses,
        }

    def assert_streams(self):
        order = self.order.state_dict()
        for trainer in self.baselines.values():
            other = trainer.order.state_dict()
            for key in order:
                a, b = order[key], other[key]
                if isinstance(a, torch.Tensor):
                    if not torch.equal(a, b):
                        raise ValueError("source sampler differs")
                elif a != b:
                    raise ValueError("source sampler differs")
            if trainer.step != self.step or not torch.equal(
                trainer.transform_rng.get_state(), self.transform_rng.get_state()
            ):
                raise ValueError("source update or lighting streams differ")
            if not torch.equal(trainer.noise_rng.get_state(), self.noise_rng.get_state()):
                raise ValueError("gaussian streams differ")

    def state(self, protocol_sha256):
        self.assert_streams()
        if state_hash(self.encoder.raw.encoder.state_dict()) != self.encoder.raw.encoder_hash:
            raise ValueError("frozen encoder changed")
        return {
            "step": self.step,
            "seed": self.seed,
            "category": self.data.category,
            "arms": self.arms,
            "protocol_sha256": protocol_sha256,
            "encoder_sha256": self.encoder.raw.encoder_hash,
            "local_variant_sha256": self.local_variant_sha256,
            "models": {a: [cpu(n.state_dict()) for n in m] for a, m in self.models.items()},
            "optimizers": {a: [cpu(o.state_dict()) for o in opts] for a, opts in self.opts.items()},
            "order": cpu(self.order.state_dict()),
            "transform_rng": self.transform_rng.get_state(),
            "noise_rng": self.noise_rng.get_state(),
            "rng": capture_rng_state(cuda=self.device.type == "cuda"),
        }

    def restore(self, state, protocol_sha256):
        if (
            state["seed"],
            state["category"],
            state["arms"],
            state["protocol_sha256"],
            state["encoder_sha256"],
            state["local_variant_sha256"],
        ) != (
            self.seed,
            self.data.category,
            self.arms,
            protocol_sha256,
            self.encoder.raw.encoder_hash,
            self.local_variant_sha256,
        ):
            raise ValueError("continuation provenance differs")
        for arm, nets in self.models.items():
            for net, saved in zip(nets, state["models"][arm], strict=True):
                net.load_state_dict(saved)
            for opt, saved in zip(self.opts[arm], state["optimizers"][arm], strict=True):
                opt.load_state_dict(saved)
        self.step = state["step"]
        self.order.load_state_dict(state["order"])
        self.transform_rng.set_state(state["transform_rng"].cpu())
        self.noise_rng.set_state(state["noise_rng"].cpu())
        for trainer in self.baselines.values():
            trainer.step = self.step
            trainer.order.load_state_dict(state["order"])
            trainer.transform_rng.set_state(state["transform_rng"].cpu())
            trainer.noise_rng.set_state(state["noise_rng"].cpu())
        restore_rng_state(state["rng"])
        self.encoder.clear()
        self.assert_streams()
