"""Direct proposal routing with the original AD2 baseline's combined hinge means."""

import torch
from torch.func import functional_call
from torch.nn import functional as F


def pure_objective(
    adapter, discriminator, clean, relit, noise, *, inference_normalization=False, lambda_score=0.1
):
    z = adapter(torch.cat((clean, relit)))
    if noise.shape != z.shape:
        raise ValueError("aligned per-view gaussian noise required")
    joint = torch.cat((z, z + noise))
    scores = discriminator(joint)
    normal, fake = scores.split(len(z))
    classification = F.relu(0.5 - normal).mean() + F.relu(0.5 + fake).mean()
    modes = [(m, m.training) for m in discriminator.modules()]
    state = {name: p.detach() for name, p in discriminator.named_parameters()}
    state.update({name: b.detach().clone() for name, b in discriminator.named_buffers()})
    if inference_normalization:
        discriminator.eval()
    try:
        output = functional_call(discriminator, state, (joint,), strict=True)
        protected_normal = output[: len(z)]
        n0, n1 = protected_normal.chunk(2)
        consistency = F.mse_loss(n0, n1)
    finally:
        for module, mode in modes:
            module.training = mode
    return {
        "total": classification + lambda_score * consistency,
        "discrimination": classification,
        "consistency": consistency,
    }
