"""Protect classifier gradients from normal consistency; bound defect targets."""

import sys
from pathlib import Path

import torch
from torch.func import functional_call
from torch.nn import functional as F

PARENT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PARENT / "local-global-synthesis-20261115"))
from local_global_model import focal_ohem, mine  # noqa: E402


def bounded_lift(n0, n1, d0, d1, support):
    if support.dtype != torch.bool or support.shape != (n0.numel(),):
        raise ValueError("aligned visible-support mask required")
    if any(s.shape != n0.shape for s in (n1, d0, d1)):
        raise ValueError("aligned raw normality scores required")
    target = ((-d0).sigmoid() - (-n0).sigmoid()).clamp_min(0).detach().reshape(-1)
    current = ((-d1).sigmoid() - (-n1).sigmoid()).reshape(-1)
    if support.any():
        return F.relu(target[support] - current[support]).square().mean()
    return current.sum() * 0


def objective(
    adapter,
    discriminator,
    normal,
    relit,
    changed0,
    changed1,
    noise,
    masks,
    *,
    route_normal=True,
    use_lift=True,
    lambda_normal=0.1,
    lambda_lift=0.1,
):
    if masks.dtype != torch.bool or masks.shape != (2, len(normal)):
        raise ValueError("paired visible supports required")
    if any(x.shape != normal.shape for x in (relit, changed0, changed1)):
        raise ValueError("aligned normal and changed features required")
    z = adapter(torch.cat((normal, relit)))
    delta = mine(discriminator, z, noise)
    n0, n1, f0, f1 = discriminator(torch.cat((z, z + delta))).chunk(4)
    discrimination = (
        F.softplus(-n0).mean()
        + F.softplus(-n1).mean()
        + F.softplus(f0).mean()
        + F.softplus(f1).mean()
    ) / 2
    modes = [(m, m.training) for m in discriminator.modules()]
    discriminator.eval()
    try:
        aux = adapter(torch.cat((normal, relit, changed0, changed1)))
        a0, a1, d0, d1 = discriminator(aux).chunk(4)
        if route_normal:
            state = {name: p.detach() for name, p in discriminator.named_parameters()}
            state.update({name: b.detach().clone() for name, b in discriminator.named_buffers()})
            protected = functional_call(discriminator, state, (aux,), strict=True).chunk(4)
            consistency = F.mse_loss(protected[0], protected[1])
        else:
            consistency = F.mse_loss(a0, a1)
    finally:
        for module, mode in modes:
            module.training = mode
    local = focal_ohem(torch.cat((d0, d1)), masks.reshape(-1))
    lift = bounded_lift(a0, a1, d0, d1, masks[0] & masks[1]) if use_lift else a0.sum() * 0
    total = discrimination + local + lambda_normal * consistency
    if use_lift:
        total = total + lambda_lift * lift
    return {
        "total": total,
        "discrimination": discrimination,
        "local_focal": local,
        "normal_consistency": consistency,
        "one_sided_lift": lift,
    }
