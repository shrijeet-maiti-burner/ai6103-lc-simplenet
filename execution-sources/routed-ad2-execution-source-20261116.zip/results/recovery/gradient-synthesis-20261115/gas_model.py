"""GLASS-inspired negative mining for original raw-normality SimpleNet heads.

This is GAS only, not a reproduction of the full GLASS system. Mining uses
running BN statistics without changing them; the final training forward still
uses the caller's normal BN mode. No real image/feature is projected.
"""

import math

import torch
from torch.nn import functional as F


def mine(
    discriminator,
    features,
    noise,
    *,
    steps=20,
    step_size=0.001,
    project_every=5,
    inner_radius=0.5,
    outer_radius=1.0,
):
    if (
        features.ndim != 2
        or features.shape != noise.shape
        or features.device != noise.device
        or features.dtype != noise.dtype
        or not torch.isfinite(features).all()
        or not torch.isfinite(noise).all()
    ):
        raise ValueError("aligned finite feature/noise matrices required")
    if (
        type(steps) is not int
        or steps < 0
        or type(project_every) is not int
        or project_every < 1
        or not all(math.isfinite(x) and x > 0 for x in (step_size, inner_radius, outer_radius))
        or inner_radius > outer_radius
    ):
        raise ValueError("invalid mining settings")
    modes = [(m, m.training) for m in discriminator.modules()]
    discriminator.eval()
    base = features.detach()
    delta = noise.detach().clone()
    try:
        for step in range(steps):
            fake = (base + delta).detach().requires_grad_(True)
            # D is raw normality: softplus(D(fake)) is the fake-class BCE.
            # Ascent finds perturbations the discriminator calls normal.
            loss = F.softplus(discriminator(fake)).mean()
            (grad,) = torch.autograd.grad(loss, fake, only_inputs=True)
            with torch.no_grad():
                delta = delta + step_size * F.normalize(grad, dim=1, eps=1e-10)
                if (step + 1) % project_every == 0:
                    norms = delta.norm(dim=1, keepdim=True)
                    delta = delta * norms.clamp(inner_radius, outer_radius) / norms.clamp_min(1e-10)
        if not torch.isfinite(delta).all():
            raise FloatingPointError("nonfinite mined perturbation")
        return delta.detach()
    finally:
        for module, mode in modes:
            module.training = mode


def objective(
    adapter,
    discriminator,
    clean,
    relit,
    noise,
    *,
    mining=False,
    lambda_score=0.0,
    **mining_settings,
):
    from lc_simplenet.paired_losses import paired_objective

    z = adapter(torch.cat((clean, relit)))
    delta = mine(discriminator, z, noise, **mining_settings) if mining else noise
    n0, n1, f0, f1 = discriminator(torch.cat((z, z + delta))).chunk(4)
    return paired_objective(n0, n1, f0, f1, margin=0.5, lambda_score=lambda_score)
