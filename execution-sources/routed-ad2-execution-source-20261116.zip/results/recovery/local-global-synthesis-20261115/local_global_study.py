"""Execution-only recipe; historical study plans and entry points excluded."""
import hashlib
import numpy as np
from author_perlin import rand_perlin_2d_np
from local_global_model import objective
from lc_simplenet.anchored_pilot import optimizers

POLICY = {'optimizer': {'adapter_lr': 0.0001, 'adapter_weight_decay': 0.01, 'discriminator_lr': 0.0002, 'discriminator_weight_decay': 1e-05}}

def synthesize(normal, texture, key):
    seed = int(hashlib.sha256(key.encode()).hexdigest()[:8], 16)
    rng = np.random.default_rng(seed)
    previous = np.random.get_state()
    np.random.seed(seed)
    try:
        for _attempt in range(64):
            masks = []
            for _ in range(2):
                res = tuple(2 ** int(v) for v in rng.integers(0, 6, size=2))
                noise = rand_perlin_2d_np((256, 256), res)
                masks.append(np.rot90(noise, int(rng.integers(0, 4))) > 0.5)
            choice = int(rng.integers(0, 3))
            mask = [masks[0] & masks[1], masks[0] | masks[1], masks[0]][choice]
            if mask.any():
                break
        else:
            raise ValueError("no visible Perlin region")
    finally:
        np.random.set_state(previous)
    texture = np.rot90(texture, int(rng.integers(0, 4)))
    if rng.random() < 0.5:
        texture = np.fliplr(texture)
    contrast, brightness = rng.uniform(0.8, 1.2, size=2)
    mean = texture.mean(axis=(0, 1), keepdims=True)
    texture = np.clip((texture - mean) * contrast + mean, 0, 1)
    texture = np.clip(texture * brightness, 0, 1)
    beta = float(np.clip(rng.normal(0.5, 0.1), 0.2, 0.8))
    changed = normal.copy()
    changed[mask] = beta * normal[mask] + (1 - beta) * texture[mask]
    return changed, {"seed": seed, "beta": beta, "perlin_pixels": int(mask.sum())}
