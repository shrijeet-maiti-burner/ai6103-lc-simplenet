"""Local/global synthetic supervision with one-sided defect-lift preservation.

GAS and local texture/focal supervision are adapted from GLASS (ECCV 2024).
The original SimpleNet E/A/D and single-view raw-score readout remain intact.
This is not the authors' full GLASS training or an established recall guarantee.
"""

import sys
from pathlib import Path

import torch
from torch.nn import functional as F

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "gradient-synthesis-20261115"))
from gas_model import mine  # noqa: E402


def one_sided_lift(n0, n1, d0, d1, support):
    """Do not let the clean branch shrink to meet the weaker relit response."""
    if support.dtype != torch.bool or support.shape != (n0.numel(),):
        raise ValueError("aligned boolean support required")
    if any(s.shape != n0.shape for s in (n1, d0, d1)):
        raise ValueError("aligned scores required")
    target = (n0 - d0).detach().reshape(-1)
    current = (n1 - d1).reshape(-1)
    if support.any():
        return F.relu(target[support] - current[support]).square().mean()
    return current.sum() * 0


def focal_ohem(normality, labels):
    # The author uses anomaly probability; -normality is its raw logit.
    logits = -normality.reshape(-1)
    target = labels.to(logits.dtype).reshape(-1)
    prob = logits.sigmoid()
    error = (prob - target).square().detach()
    keep = error >= torch.quantile(error, 0.5)
    bce = F.binary_cross_entropy_with_logits(logits, target, reduction="none")
    pt = torch.where(target > 0, prob, 1 - prob)
    return (((1 - pt) ** 2) * bce)[keep].mean()


def objective(
    adapter,
    discriminator,
    normal,
    relit,
    changed0,
    changed1,
    noise,
    masks,
    *,
    lambda_normal=0.0,
    lambda_lift=0.0,
):
    if masks.dtype != torch.bool or masks.shape != (2, len(normal)):
        raise ValueError("paired visible synthetic supports required")
    if any(x.shape != normal.shape for x in (relit, changed0, changed1)):
        raise ValueError("aligned original and changed features required")
    z = adapter(torch.cat((normal, relit)))
    delta = mine(discriminator, z, noise)
    n0, n1, f0, f1 = discriminator(torch.cat((z, z + delta))).chunk(4)
    discrimination = (
        F.softplus(-n0).mean()
        + F.softplus(-n1).mean()
        + F.softplus(f0).mean()
        + F.softplus(f1).mean()
    ) / 2
    # Extra image-level supervision must not alter running BN statistics.
    # It uses the inference normalization, while gradients still train A/D.
    modes = [(m, m.training) for m in discriminator.modules()]
    discriminator.eval()
    try:
        a0, a1, d0, d1 = discriminator(
            adapter(torch.cat((normal, relit, changed0, changed1)))
        ).chunk(4)
    finally:
        for module, mode in modes:
            module.training = mode
    local = focal_ohem(torch.cat((d0, d1)), masks.reshape(-1))
    # Preserve the actual inference function, rather than a training-batch scale.
    consistency = F.mse_loss(a0, a1)
    lift = one_sided_lift(a0, a1, d0, d1, masks[0] & masks[1])
    total = discrimination + local
    if lambda_normal:
        total = total + lambda_normal * consistency
    if lambda_lift:
        total = total + lambda_lift * lift
    return {
        "total": total,
        "discrimination": discrimination,
        "local_focal": local,
        "normal_consistency": consistency,
        "one_sided_lift": lift,
    }
