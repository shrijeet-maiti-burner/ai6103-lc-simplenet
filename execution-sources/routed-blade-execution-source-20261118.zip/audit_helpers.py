from collections import defaultdict
import numpy as np
from scipy.stats import rankdata
def auc(scores, labels):
    n1 = int(labels.sum())
    n0 = len(labels) - n1
    ranks = rankdata(scores, method="average")
    return float((ranks[labels].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))

def paired_interval(differences, hashes, rng, replicates):
    groups = defaultdict(list)
    for i, value in enumerate(hashes):
        groups[value].append(i)
    ids = sorted(groups)
    sizes = np.array([len(groups[key]) for key in ids])
    totals = np.array([differences[groups[key]].sum() for key in ids])
    sample = rng.integers(0, len(ids), size=(replicates, len(ids)))
    boot = totals[sample].sum(axis=1) / sizes[sample].sum(axis=1)
    return {
        "difference": float(differences.mean()),
        "ci95": np.quantile(boot, [0.025, 0.975]).tolist(),
        "image_count": len(hashes),
        "exact_RGB_cluster_count": len(ids),
    }

