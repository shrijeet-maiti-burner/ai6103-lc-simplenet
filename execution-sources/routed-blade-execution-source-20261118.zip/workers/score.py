"""Framed, RAM-only execution on a Slurm-allocated L40S. No target-based training."""

import base64
import copy
import hashlib
import io
import json
import os
import random
import sys
import tempfile
import time
import traceback
import types
import zipfile
from pathlib import Path

WIRE = sys.stdout.buffer
sys.stdout = sys.stderr


def send(data):
    if len(data) > 600 * 2**20:
        raise ValueError("oversized frame")
    WIRE.write(str(len(data)).encode() + b"\n")
    for i in range(0, len(data), 48 * 2**10):
        WIRE.write(base64.b64encode(data[i : i + 48 * 2**10]) + b"\n")
    WIRE.flush()


def receive():
    line = sys.stdin.buffer.readline(32)
    if not line.endswith(b"\n"):
        raise EOFError("missing frame header")
    size = int(line.strip())
    if not 0 <= size <= 600 * 2**20:
        raise ValueError("oversized frame")
    output = bytearray()
    while len(output) < size:
        line = sys.stdin.buffer.readline(65539)
        if not line.endswith(b"\n"):
            raise EOFError("incomplete frame")
        output.extend(base64.b64decode(line.rstrip(b"\r\n"), validate=True))
        if len(output) > size:
            raise ValueError("frame length exceeded")
    return bytes(output)


def message(value):
    send(json.dumps(value, allow_nan=False).encode())


def emit(name, data, **metadata):
    message(
        {
            "state": "artifact",
            "name": name,
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            **metadata,
        }
    )
    send(data)


def emit_json(name, value):
    emit(name, json.dumps(value, indent=2, allow_nan=False).encode())


def cpu(value):
    import torch

    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {k: cpu(v) for k, v in value.items()}
    if isinstance(value, tuple):
        return tuple(cpu(v) for v in value)
    if isinstance(value, list):
        return [cpu(v) for v in value]
    return value


def tensor_hash(state):
    h = hashlib.sha256()
    for key, value in sorted(state.items()):
        a = value.detach().cpu().contiguous().numpy()
        h.update(f"{key}:{a.dtype}:{a.shape}:".encode())
        h.update(memoryview(a).cast("B"))
    return h.hexdigest()


"""Cache only the public pinned ImageNet backbone, never images or credentials."""

import hashlib
import os
from pathlib import Path

BACKBONE_SHA256 = "95faca4d11227dddf8633dbb5ff6c8a9003c1aa5b8945c73834b8007b10950b8"


def cache_directory():
    directory = Path("/tmp") / f"ai6103-backbone-{os.getuid()}"
    if directory.exists() and (directory.is_symlink() or directory.stat().st_uid != os.getuid()):
        raise OSError("cache owner/path mismatch")
    return directory


def read_cached_backbone():
    try:
        directory = cache_directory()
        path = directory / "wide_resnet50_2-95faca4d.pth"
        if not path.is_file() or path.is_symlink() or path.stat().st_uid != os.getuid():
            return None
        raw = path.read_bytes()
        return raw if hashlib.sha256(raw).hexdigest() == BACKBONE_SHA256 else None
    except OSError:
        return None


def cache_verified_backbone(raw):
    if hashlib.sha256(raw).hexdigest() != BACKBONE_SHA256:
        raise ValueError("refuse to cache an unverified backbone")
    pending = None
    try:
        directory = cache_directory()
        directory.mkdir(mode=0o700, exist_ok=True)
        pending = directory / f"backbone-{os.getpid()}.part"
        fd = os.open(pending, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(pending, directory / "wide_resnet50_2-95faca4d.pth")
        return True
    except OSError:
        if pending is not None and pending.is_file() and not pending.is_symlink():
            pending.unlink(missing_ok=True)
        return False


"""Read-only source confirmation or frozen-domain inference; no fitting path."""


def main():
    import numpy as np
    import torch
    import torchvision
    import torchvision.models._api as tv_api

    if (
        str(torch.__version__),
        str(torchvision.__version__),
        np.__version__,
        torch.cuda.get_device_name(),
    ) != ("2.6.0+cu124", "0.21.0+cu124", "1.26.4", "NVIDIA L40S"):
        raise ValueError("unverified inference runtime")
    torch.set_num_threads(4)
    cached_weights = read_cached_backbone()
    message(
        {
            "state": "ready",
            "gpu": torch.cuda.get_device_name(),
            "job_id": os.environ.get("SLURM_JOB_ID"),
            "backbone_cached_sha256": BACKBONE_SHA256 if cached_weights is not None else None,
        }
    )
    launch = json.loads(receive())
    raw = receive()
    if hashlib.sha256(raw).hexdigest() != launch["runtime_sha256"]:
        raise ValueError("runtime differs")
    with tempfile.TemporaryDirectory(prefix="ai6103-lg-score-", dir="/dev/shm") as temporary:
        root = Path(temporary)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            if set(z.namelist()) != set(launch["runtime_files"]):
                raise ValueError("runtime members differ")
            for name in z.namelist():
                relative = Path(name)
                if relative.is_absolute() or ".." in relative.parts:
                    raise ValueError("unsafe source")
                data = z.read(name)
                if hashlib.sha256(data).hexdigest() != launch["runtime_files"][name]:
                    raise ValueError("source hash differs")
                path = root / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
        old = root / "results/recovery/gradient-synthesis-20261115"
        local = root / "results/recovery/local-global-synthesis-20261115"
        full = root / "results/recovery/full-budget-local-global-20261115"
        sys.path[:0] = [str(root / "src"), str(full), str(local), str(old)]
        import local_global_study as recipe
        from lc_simplenet.anchored_pilot import synthetic_changes
        from lc_simplenet.pilot import PilotConfig, UpstreamBackend, seed_runtime

        recipe.verify()
        raw = cached_weights if cached_weights is not None else receive()
        if hashlib.sha256(raw).hexdigest() != launch["backbone_sha256"]:
            raise ValueError("backbone differs")
        cache_verified_backbone(raw)
        weights = torch.load(io.BytesIO(raw), map_location="cpu", weights_only=True)
        cached_weights = None

        def supplied_weights(url, *args, **kwargs):
            if url != "https://download.pytorch.org/models/wide_resnet50_2-95faca4d.pth":
                raise ValueError("unexpected weights")
            return weights

        tv_api.load_state_dict_from_url = supplied_weights
        guard = types.ModuleType("metrics")
        guard.__file__ = "<excluded-author-test-metrics>"

        def forbidden(name):
            if name.startswith("__"):
                raise AttributeError(name)

            def reject(*args, **kwargs):
                raise RuntimeError("excluded author test metric: " + name)

            return reject

        guard.__getattr__ = forbidden
        sys.modules["metrics"] = guard
        seed_runtime(0)
        backend = UpstreamBackend(
            PilotConfig("aebad", "blade", launch["study_protocol_sha256"], image_size=(256, 256)),
            torch.device("cuda"),
        )
        encoder_hash = tensor_hash(backend.encoder.state_dict())
        raw = receive()
        if hashlib.sha256(raw).hexdigest() != launch["heads_sha256"]:
            raise ValueError("head pack differs")
        pack = torch.load(io.BytesIO(raw), map_location="cpu", weights_only=True)
        if (pack["protocol_sha256"], pack["steps"], pack["encoder_sha256"]) != (
            launch["study_protocol_sha256"],
            5120,
            encoder_hash,
        ):
            raise ValueError("trained head provenance differs")
        arms = ["B0", "B1", "B2", "L0", "L1", "L2", "L3", "R0", "R1", "R2", "P0", "P1"]
        seeds = [0, 1, 2]
        if (
            pack["source_protocols"] != launch["source_protocols"]
            or pack["primary"] != launch["primary"]
        ):
            raise ValueError("parent sources or source-selected recipe changed")
        if pack["arms"] != arms or pack["seeds"] != seeds:
            raise ValueError("incomplete head matrix")
        raw = receive()
        if hashlib.sha256(raw).hexdigest() != launch["input_sha256"]:
            raise ValueError("RGB bundle differs")
        dataset = zipfile.ZipFile(io.BytesIO(raw))
        rows = launch["rows"]
        if set(dataset.namelist()) != {r["image_id"] for r in rows}:
            raise ValueError("input population differs")
        if launch["mode"] in ["confirmation", "replay"]:
            role = "confirmation" if launch["mode"] == "confirmation" else "development"
            expected = recipe.read(old / "protocol.json")["roles"][role]
            if rows != expected or len(rows) != 64:
                raise ValueError("fresh source role differs")
            views_per_parent = 20
        elif launch["mode"] == "test":
            if launch["domain"] not in ["illumination", "same", "background", "view"]:
                raise ValueError("undeclared test domain")
            if any(
                not r["image_id"].startswith("AeBAD/AeBAD_S/test/")
                or r["image_id"].split("/")[-2] != launch["domain"]
                for r in rows
            ):
                raise ValueError("test population/domain mismatch")
            views_per_parent = 1
        else:
            raise ValueError("no training or arbitrary scoring mode is provided")
        features = torch.empty((len(rows), views_per_parent, 1024, 1536), device="cuda")
        feature_hash = hashlib.sha256()
        native_rgb = {}
        tick = time.monotonic()
        for i, row in enumerate(rows):
            # Hash native RGB separately for overlap/duplicate auditing.
            from PIL import Image

            with Image.open(io.BytesIO(dataset.read(row["image_id"]))) as im:
                rgb = im.convert("RGB")
                native_rgb[row["image_id"]] = hashlib.sha256(
                    f"RGB:{rgb.width}:{rgb.height}:".encode() + rgb.tobytes()
                ).hexdigest()
            normal = recipe.load_rgb(dataset, row)
            if launch["mode"] in ["confirmation", "replay"]:
                donor = recipe.load_rgb(dataset, rows[(i + 1) % len(rows)])
                role_seed = (
                    "gas-aebad-confirmation-v1"
                    if launch["mode"] == "confirmation"
                    else "gas-aebad-development-v1"
                )
                variants = [normal, *synthetic_changes(normal, donor, row["image_id"], role_seed)]
                views = [
                    recipe.relight(im, brightness=b, gamma=g)
                    for im in variants
                    for b, g in recipe.LIGHTS
                ]
            else:
                views = [normal]
            f = np.concatenate(
                [recipe.encode(backend, views[j : j + 4]) for j in range(0, len(views), 4)]
            )
            feature_hash.update(memoryview(f).cast("B"))
            features[i] = torch.from_numpy(f).cuda()
            if (i + 1) % 64 == 0:
                message({"state": "features", "parents": i + 1, "seconds": time.monotonic() - tick})
        image_scores = {}
        patch_scores = {}
        before = {}
        after = {}
        metrics = {}
        for seed in seeds:
            metrics[str(seed)] = {}
            for arm in arms:
                nets = recipe.new_heads(seed)
                for net, state in zip(nets, pack["models"][str(seed)][arm], strict=True):
                    net.load_state_dict(state)
                    net.eval()
                    net.requires_grad_(False)
                key = f"seed{seed}_{arm}"
                before[key] = [tensor_hash(n.state_dict()) for n in nets]
                all_scores = []
                with torch.no_grad():
                    for i in range(len(rows)):
                        # Keep the exact one-view GEMM shape used in calibration.
                        p = torch.stack([(-nets[1](nets[0](f))).reshape(1024) for f in features[i]])
                        all_scores.append(p.cpu().numpy())
                p = np.stack(all_scores)
                if not np.isfinite(p).all():
                    raise ValueError("nonfinite prediction")
                scores = p.max(axis=-1)
                q = pack["thresholds"][str(seed)][arm]
                flag = scores > q
                if launch["mode"] in ["confirmation", "replay"]:
                    flag = flag.reshape(64, 4, 5)
                    value = {
                        "clean_fpr": float(flag[:, 0, 0].mean()),
                        "corner_fpr": float(flag[:, 0, 1:].mean()),
                        "clean_procedural_recall": float(flag[:, 1:, 0].mean()),
                        "corner_procedural_recall": float(flag[:, 1:, 1:].mean()),
                    }
                else:
                    labels = np.array([r["label"] for r in rows], dtype=bool)
                    value = {
                        "normal_count": int((~labels).sum()),
                        "defect_count": int(labels.sum()),
                        "false_positives": int(flag.reshape(-1)[~labels].sum()),
                        "true_positives": int(flag.reshape(-1)[labels].sum()),
                        "fpr": float(flag.reshape(-1)[~labels].mean()),
                        "recall": float(flag.reshape(-1)[labels].mean()),
                    }
                metrics[str(seed)][arm] = {**value, "threshold": q}
                image_scores[key] = scores
                patch_scores[key] = p
                after[key] = [tensor_hash(n.state_dict()) for n in nets]
                if after[key] != before[key]:
                    raise ValueError("inference changed head state")
                del nets
        if tensor_hash(backend.encoder.state_dict()) != encoder_hash:
            raise ValueError("inference changed encoder")
        emit_json(
            "metrics.json",
            {
                "metrics": metrics,
                "mode": launch["mode"],
                "domain": launch.get("domain"),
                "thresholds_refitted": False,
                "study_protocol_sha256": launch["study_protocol_sha256"],
                "feature_sha256": feature_hash.hexdigest(),
                "native_rgb_sha256": native_rgb,
                "all_head_parameters_and_buffers_unchanged": True,
                "encoder_unchanged": True,
                "source_head_pack_sha256": launch["heads_sha256"],
                "source_protocols": pack["source_protocols"],
                "primary": pack["primary"],
            },
        )
        buffer = io.BytesIO()
        np.savez_compressed(buffer, **image_scores)
        emit("image-scores.npz", buffer.getvalue())
        buffer = io.BytesIO()
        np.savez_compressed(buffer, **patch_scores)
        emit("patch-scores.npz", buffer.getvalue())
        message({"state": "complete"})


try:
    main()
except BaseException:
    traceback.print_exc(file=sys.stderr)
    raise
