"""Framed, RAM-only execution on a Slurm-allocated L40S. No target-based training."""

import base64
import copy
import hashlib
import io
import json
import os
import random
import sys
import tempfile
import time
import traceback
import types
import zipfile
from pathlib import Path

WIRE = sys.stdout.buffer
sys.stdout = sys.stderr


def send(data):
    if len(data) > 600 * 2**20:
        raise ValueError("oversized frame")
    WIRE.write(str(len(data)).encode() + b"\n")
    for i in range(0, len(data), 48 * 2**10):
        WIRE.write(base64.b64encode(data[i : i + 48 * 2**10]) + b"\n")
    WIRE.flush()


def receive():
    line = sys.stdin.buffer.readline(32)
    if not line.endswith(b"\n"):
        raise EOFError("missing frame header")
    size = int(line.strip())
    if not 0 <= size <= 600 * 2**20:
        raise ValueError("oversized frame")
    output = bytearray()
    while len(output) < size:
        line = sys.stdin.buffer.readline(65539)
        if not line.endswith(b"\n"):
            raise EOFError("incomplete frame")
        output.extend(base64.b64decode(line.rstrip(b"\r\n"), validate=True))
        if len(output) > size:
            raise ValueError("frame length exceeded")
    return bytes(output)


def message(value):
    send(json.dumps(value, allow_nan=False).encode())


def emit(name, data, **metadata):
    message(
        {
            "state": "artifact",
            "name": name,
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            **metadata,
        }
    )
    send(data)


def emit_json(name, value):
    emit(name, json.dumps(value, indent=2, allow_nan=False).encode())


def cpu(value):
    import torch

    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {k: cpu(v) for k, v in value.items()}
    if isinstance(value, tuple):
        return tuple(cpu(v) for v in value)
    if isinstance(value, list):
        return [cpu(v) for v in value]
    return value


def tensor_hash(state):
    h = hashlib.sha256()
    for key, value in sorted(state.items()):
        a = value.detach().cpu().contiguous().numpy()
        h.update(f"{key}:{a.dtype}:{a.shape}:".encode())
        h.update(memoryview(a).cast("B"))
    return h.hexdigest()


"""Cache only the public pinned ImageNet backbone, never images or credentials."""

import hashlib
import os
from pathlib import Path

BACKBONE_SHA256 = "95faca4d11227dddf8633dbb5ff6c8a9003c1aa5b8945c73834b8007b10950b8"


def cache_directory():
    directory = Path("/tmp") / f"ai6103-backbone-{os.getuid()}"
    if directory.exists() and (directory.is_symlink() or directory.stat().st_uid != os.getuid()):
        raise OSError("cache owner/path mismatch")
    return directory


def read_cached_backbone():
    try:
        directory = cache_directory()
        path = directory / "wide_resnet50_2-95faca4d.pth"
        if not path.is_file() or path.is_symlink() or path.stat().st_uid != os.getuid():
            return None
        raw = path.read_bytes()
        return raw if hashlib.sha256(raw).hexdigest() == BACKBONE_SHA256 else None
    except OSError:
        return None


def cache_verified_backbone(raw):
    if hashlib.sha256(raw).hexdigest() != BACKBONE_SHA256:
        raise ValueError("refuse to cache an unverified backbone")
    pending = None
    try:
        directory = cache_directory()
        directory.mkdir(mode=0o700, exist_ok=True)
        pending = directory / f"backbone-{os.getpid()}.part"
        fd = os.open(pending, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(pending, directory / "wide_resnet50_2-95faca4d.pth")
        return True
    except OSError:
        if pending is not None and pending.is_file() and not pending.is_symlink():
            pending.unlink(missing_ok=True)
        return False

"""RAM-only full-budget source experiment; framing helpers precede this file."""


def main():
    job_started = time.monotonic()
    import numpy as np
    import torch
    import torchvision
    import torchvision.models._api as tv_api
    from PIL import Image

    if (
        str(torch.__version__),
        str(torchvision.__version__),
        np.__version__,
        torch.cuda.get_device_name(),
    ) != ("2.6.0+cu124", "0.21.0+cu124", "1.26.4", "NVIDIA L40S"):
        raise ValueError("unverified runtime")
    torch.set_num_threads(4)
    cached_weights = read_cached_backbone()
    message(
        {
            "state": "ready",
            "gpu": torch.cuda.get_device_name(),
            "job_id": os.environ.get("SLURM_JOB_ID"),
            "torch": str(torch.__version__),
            "backbone_cached_sha256": BACKBONE_SHA256 if cached_weights is not None else None,
        }
    )
    launch = json.loads(receive())
    raw = receive()
    if hashlib.sha256(raw).hexdigest() != launch["runtime_sha256"]:
        raise ValueError("runtime bundle changed")
    with tempfile.TemporaryDirectory(prefix="ai6103-lg-full-", dir="/dev/shm") as temporary:
        root = Path(temporary)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            if set(z.namelist()) != set(launch["runtime_files"]):
                raise ValueError("source members differ")
            for name in z.namelist():
                relative = Path(name)
                if relative.is_absolute() or ".." in relative.parts:
                    raise ValueError("unsafe source")
                data = z.read(name)
                if hashlib.sha256(data).hexdigest() != launch["runtime_files"][name]:
                    raise ValueError("source hash differs")
                path = root / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
        old = root / "results/recovery/gradient-synthesis-20261115"
        local = root / "results/recovery/local-global-synthesis-20261115"
        sys.path[:0] = [str(root / "src"), str(local), str(old)]
        import local_global_study as recipe
        pure = root / "results/recovery/pure-routed-consistency-20261116"
        sys.path.insert(0, str(pure))
        import pure_model
        from gas_model import objective as gaussian_objective
        from lc_simplenet.anchored_pilot import synthetic_changes
        from lc_simplenet.pilot import PilotConfig, UpstreamBackend, seed_runtime

        recipe.verify()
        original = recipe.read(old / "protocol.json")
        textures = recipe.read(recipe.TEXTURES / "manifest.json")["files"]
        roles = original["roles"]
        ARMS = ["P0", "P1"]
        POLICY = {
            "fit": 128,
            "batch": 4,
            "passes": 160,
            "updates": 5120,
            "arms": ARMS,
            "seeds": [0, 1, 2],
            "optimizer": recipe.POLICY["optimizer"],
            "frozen_recipe": recipe.POLICY,
            "pure_arms": {'P0': {'inference_normalization': False}, 'P1': {'inference_normalization': True}},
        }
        if launch["policy"] != json.loads(json.dumps(POLICY)):
            raise ValueError("policy differs")
        raw = cached_weights if cached_weights is not None else receive()
        if hashlib.sha256(raw).hexdigest() != launch["backbone_sha256"]:
            raise ValueError("backbone differs")
        cache_verified_backbone(raw)
        weights = torch.load(io.BytesIO(raw), map_location="cpu", weights_only=True)
        cached_weights = None

        def supplied_weights(url, *args, **kwargs):
            if url != "https://download.pytorch.org/models/wide_resnet50_2-95faca4d.pth":
                raise ValueError("unexpected weights")
            return weights

        tv_api.load_state_dict_from_url = supplied_weights
        guard = types.ModuleType("metrics")
        guard.__file__ = "<excluded-author-test-metrics>"

        def forbidden(name):
            if name.startswith("__"):
                raise AttributeError(name)

            def reject(*args, **kwargs):
                raise RuntimeError("excluded author test metric: " + name)

            return reject

        guard.__getattr__ = forbidden
        sys.modules["metrics"] = guard
        seed_runtime(0)
        backend = UpstreamBackend(
            PilotConfig("aebad", "blade", launch["protocol_sha256"], image_size=(256, 256)),
            torch.device("cuda"),
        )
        encoder_hash = tensor_hash(backend.encoder.state_dict())
        raw = receive()
        if hashlib.sha256(raw).hexdigest() != launch["input_sha256"]:
            raise ValueError("source RGB bundle differs")
        dataset = zipfile.ZipFile(io.BytesIO(raw))
        wanted = {
            r["image_id"] for role in ["fit", "calibration", "development"] for r in roles[role]
        }
        wanted.update("textures/" + t["path"] for t in textures)
        if set(dataset.namelist()) != wanted:
            raise ValueError("source-only bundle population differs")
        normal_features = torch.empty((128, 5, 1024, 1536), device="cuda")
        local_features = torch.empty((128, 4, 5, 1024, 1536), device="cuda")
        supports = torch.empty((128, 4, 5, 1024), device="cuda", dtype=torch.bool)
        h = hashlib.sha256()
        tick = time.monotonic()
        for i, row in enumerate(roles["fit"]):
            normal = recipe.load_rgb(dataset, row)
            nviews = [recipe.relight(normal, brightness=b, gamma=g) for b, g in recipe.LIGHTS]
            f = np.concatenate(
                [recipe.encode(backend, nviews[:4]), recipe.encode(backend, nviews[4:])]
            )
            h.update(memoryview(f).cast("B"))
            normal_features[i] = torch.from_numpy(f).cuda()
            for variant in range(4):
                key = "local-global-synthesis-v1:" + row["image_id"] + ":" + str(variant)
                index = int(hashlib.sha256(("texture:" + key).encode()).hexdigest(), 16) % len(
                    textures
                )
                descriptor = textures[index]
                data = dataset.read("textures/" + descriptor["path"])
                if hashlib.sha256(data).hexdigest() != descriptor["sha256"]:
                    raise ValueError("texture differs")
                with Image.open(io.BytesIO(data)) as im:
                    texture = (
                        np.asarray(
                            im.convert("RGB").resize((256, 256), Image.Resampling.BILINEAR),
                            dtype=np.float32,
                        )
                        / 255
                    )
                changed, _ = recipe.synthesize(normal, texture, key)
                views = [recipe.relight(changed, brightness=b, gamma=g) for b, g in recipe.LIGHTS]
                masks = np.stack(
                    [
                        (np.max(np.abs(a - b), axis=2) > 1 / 255)
                        .reshape(32, 8, 32, 8)
                        .any(axis=(1, 3))
                        .reshape(-1)
                        for a, b in zip(nviews, views, strict=True)
                    ]
                )
                if not masks.all(axis=0).any():
                    raise ValueError("invisible training anomaly")
                f = np.concatenate(
                    [recipe.encode(backend, views[:4]), recipe.encode(backend, views[4:])]
                )
                h.update(memoryview(f).cast("B"))
                h.update(memoryview(masks).cast("B"))
                local_features[i, variant] = torch.from_numpy(f).cuda()
                supports[i, variant] = torch.from_numpy(masks).cuda()
            if (i + 1) % 32 == 0:
                message(
                    {
                        "state": "preparing_features",
                        "parents": i + 1,
                        "seconds": time.monotonic() - tick,
                    }
                )
        feature_hash = h.hexdigest()
        models = {a: recipe.new_heads(launch["seed"]) for a in ARMS}
        opts = {a: recipe.optimizers(*m, POLICY) for a, m in models.items()}
        initial = [tensor_hash(n.state_dict()) for n in models["P0"]]
        if any([tensor_hash(n.state_dict()) for n in m] != initial for m in models.values()):
            raise ValueError("initializations differ")
        sampler = torch.Generator().manual_seed(80100 + launch["seed"])
        lighting = torch.Generator().manual_seed(80200 + launch["seed"])
        noise_rng = torch.Generator().manual_seed(80300 + launch["seed"])
        start = launch["start_step"]
        end = launch["end_step"]
        per_epoch = 32
        order = None
        if start % 32 or end % 32 or not 0 <= start < end <= 5120:
            raise ValueError("invalid fixed budget")
        if start:
            raw = receive()
            if hashlib.sha256(raw).hexdigest() != launch["resume_sha256"]:
                raise ValueError("resume bytes differ")
            state = torch.load(io.BytesIO(raw), map_location="cpu", weights_only=True)
            for key, value in [
                ("step", start),
                ("seed", launch["seed"]),
                ("protocol_sha256", launch["protocol_sha256"]),
                ("feature_sha256", feature_hash),
                ("encoder_sha256", encoder_hash),
            ]:
                if state[key] != value:
                    raise ValueError("resume provenance differs: " + key)
            for arm, m in models.items():
                for net, s in zip(m, state["models"][arm], strict=True):
                    net.load_state_dict(s)
                for opt, s in zip(opts[arm], state["optimizers"][arm], strict=True):
                    opt.load_state_dict(s)
            sampler.set_state(state["sampler"])
            lighting.set_state(state["lighting"])
            noise_rng.set_state(state["noise"])
            order = state["order"]
            del state, raw
        message(
            {
                "state": "features_verified",
                "feature_sha256": feature_hash,
                "encoder_sha256": encoder_hash,
                "start_step": start,
                "end_step": end,
            }
        )

        def update(networks, optimizers, clean, shifted, c0, c1, noise, masks):
            values = {}
            for arm, (a, d) in networks.items():
                a.train()
                d.train()
                for opt in optimizers[arm]:
                    opt.zero_grad(set_to_none=True)
                terms = pure_model.objective(
                    a, d, clean, shifted, noise, lambda_score=0.1,
                    **POLICY["pure_arms"][arm],
                )
                if not all(torch.isfinite(v) for v in terms.values()):
                    raise FloatingPointError("nonfinite objective")
                terms["total"].backward()
                if not all(
                    torch.isfinite(p.grad).all()
                    for net in (a, d)
                    for p in net.parameters()
                    if p.grad is not None
                ):
                    raise FloatingPointError("nonfinite gradient")
                for opt in optimizers[arm]:
                    opt.step()
                values[arm] = {k: float(v.detach()) for k, v in terms.items()}
            return values

        def snapshot(completed):
            if tensor_hash(backend.encoder.state_dict()) != encoder_hash:
                raise ValueError("encoder changed before snapshot")
            state = {
                "step": completed,
                "seed": launch["seed"],
                "protocol_sha256": launch["protocol_sha256"],
                "feature_sha256": feature_hash,
                "encoder_sha256": encoder_hash,
                "models": {a: [cpu(n.state_dict()) for n in m] for a, m in models.items()},
                "optimizers": {a: [cpu(o.state_dict()) for o in opts[a]] for a in ARMS},
                "sampler": sampler.get_state(),
                "lighting": lighting.get_state(),
                "noise": noise_rng.get_state(),
                "order": order,
            }
            buffer = io.BytesIO()
            torch.save(state, buffer)
            emit(
                f"checkpoint-{completed:05d}.pt",
                buffer.getvalue(),
                step=completed,
                seed=launch["seed"],
            )
            del state, buffer

        tick = time.monotonic()
        logs = []
        last_saved = start
        for step in range(start, end):
            if step % 32 == 0:
                order = torch.randperm(128, generator=sampler).tolist()
            offset = (step % 32) * 4
            ids = order[offset : offset + 4]
            variant = (step // 32) % 4
            lights = torch.randint(1, 5, (4,), generator=lighting).tolist()
            clean = normal_features[ids, 0].reshape(-1, 1536)
            shifted = normal_features[ids, lights].reshape(-1, 1536)
            c0 = local_features[ids, variant, 0].reshape(-1, 1536)
            c1 = local_features[ids, variant, lights].reshape(-1, 1536)
            masks = torch.stack(
                (supports[ids, variant, 0].reshape(-1), supports[ids, variant, lights].reshape(-1))
            )
            noise = torch.randn((2 * len(clean), 1536), generator=noise_rng).cuda() * 0.015
            terms = update(models, opts, clean, shifted, c0, c1, noise, masks)
            if step == start:
                # A serialized Adam state must reproduce the next L3 update.
                original_hash = [tensor_hash(n.state_dict()) for n in models["P0"]]
                reference, reference_opts = copy.deepcopy((models["P0"], opts["P0"]))
                package = {
                    "model": [cpu(n.state_dict()) for n in models["P0"]],
                    "optimizers": [cpu(o.state_dict()) for o in opts["P0"]],
                }
                serialized = io.BytesIO()
                torch.save(package, serialized)
                restored = torch.load(
                    io.BytesIO(serialized.getvalue()), map_location="cpu", weights_only=True
                )
                restart = copy.deepcopy(models["P0"])
                restart_opts = recipe.optimizers(*restart, POLICY)
                for n, s in zip(restart, restored["model"], strict=True):
                    n.load_state_dict(s)
                for o, s in zip(restart_opts, restored["optimizers"], strict=True):
                    o.load_state_dict(s)
                probes = [reference, restart]
                probe_opts = [reference_opts, restart_opts]
                for m, optim in zip(probes, probe_opts, strict=True):
                    update({"P0": m}, {"P0": optim}, clean, shifted, c0, c1, noise, masks)
                if any(
                    tensor_hash(a.state_dict()) != tensor_hash(b.state_dict())
                    for a, b in zip(*probes, strict=True)
                ):
                    raise ValueError("restored L3 next update differs")

                def equal(a, b):
                    if isinstance(a, torch.Tensor):
                        return torch.equal(a, b)
                    if isinstance(a, dict):
                        return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
                    if isinstance(a, (list, tuple)):
                        return len(a) == len(b) and all(
                            equal(x, y) for x, y in zip(a, b, strict=True)
                        )
                    return a == b

                if not all(
                    equal(a.state_dict(), b.state_dict()) for a, b in zip(*probe_opts, strict=True)
                ):
                    raise ValueError("restored optimizer differs")
                if [tensor_hash(n.state_dict()) for n in models["P0"]] != original_hash:
                    raise ValueError("resume probe changed live model")
                emit_json(
                    "resume-mechanics.json",
                    {
                        "passed": True,
                        "next_P0_parameters_buffers_optimizer_states_bit_exact": True,
                        "live_model_unchanged": True,
                    },
                )
                del (
                    probes,
                    probe_opts,
                    package,
                    serialized,
                    restored,
                    reference,
                    reference_opts,
                    restart,
                    restart_opts,
                )
            if (step + 1) % 32 == 0:
                logs.append({"step": step + 1, "losses": terms})
            if (step + 1) % 32 == 0:
                message(
                    {
                        "state": "progress",
                        "step": step + 1,
                        "seed": launch["seed"],
                        "seconds": time.monotonic() - tick,
                        "losses": terms,
                    }
                )
            if (step + 1 - start) >= 128 and (step + 1 - start - 128) % 512 == 0:
                snapshot(step + 1)
                last_saved = step + 1
            if (step + 1) % 32 == 0 and time.monotonic() - job_started >= 3000 and step + 1 < end:
                end = step + 1
                message({"state": "walltime_checkpoint", "step": end})
                break
        if last_saved != end:
            snapshot(end)
        emit_json(
            "training.json",
            {
                "seed": launch["seed"],
                "step": end,
                "source_passes_completed": end / 32,
                "training_seconds": time.monotonic() - tick,
                "logs": logs,
                "feature_sha256": feature_hash,
                "encoder_sha256": encoder_hash,
                "peak_allocated": torch.cuda.max_memory_allocated(),
                "scope": "source-only fixed-budget training; target PNGs and masks not decoded",
            },
        )
        if end == 5120:
            del normal_features, local_features, supports, clean, shifted, c0, c1, noise, masks
            torch.cuda.empty_cache()
            arrays = {a: {"calibration": [], "development": []} for a in ARMS}
            patches = {}
            for role in ["calibration", "development"]:
                rows = roles[role]
                for i, row in enumerate(rows):
                    normal = recipe.load_rgb(dataset, row)
                    if role == "calibration":
                        views = [normal]
                    else:
                        donor = recipe.load_rgb(dataset, rows[(i + 1) % len(rows)])
                        variants = [
                            normal,
                            *synthetic_changes(
                                normal, donor, row["image_id"], "gas-aebad-development-v1"
                            ),
                        ]
                        views = [
                            recipe.relight(im, brightness=b, gamma=g)
                            for im in variants
                            for b, g in recipe.LIGHTS
                        ]
                    f = np.concatenate(
                        [recipe.encode(backend, views[j : j + 4]) for j in range(0, len(views), 4)]
                    )
                    for arm, model in models.items():
                        s = recipe.predict(model, f)
                        patches[f"{role}_{arm}_{i:03d}"] = s
                        arrays[arm][role].append(s.max(axis=1))
            metrics = {}
            for arm, values in arrays.items():
                q = float(np.quantile(np.asarray(values["calibration"]), 0.95, method="higher"))
                flags = np.asarray(values["development"]).reshape(64, 4, 5) > q
                metrics[arm] = {
                    "threshold": q,
                    "clean_fpr": float(flags[:, 0, 0].mean()),
                    "corner_fpr": float(flags[:, 0, 1:].mean()),
                    "clean_procedural_recall": float(flags[:, 1:, 0].mean()),
                    "corner_procedural_recall": float(flags[:, 1:, 1:].mean()),
                    "normal_patch_std": float(
                        np.concatenate(
                            [patches[f"calibration_{arm}_{i:03d}"].ravel() for i in range(64)]
                        ).std()
                    ),
                }
            emit_json(
                "source-screen.json",
                {
                    "metrics": metrics,
                    "seed": launch["seed"],
                    "protocol_sha256": launch["protocol_sha256"],
                    "steps": 5120,
                    "scope": "reused normal/procedural development, not independent real-defect evidence",
                },
            )
            buffer = io.BytesIO()
            np.savez_compressed(buffer, **patches)
            emit("source-patch-scores.npz", buffer.getvalue())
            buffer = io.BytesIO()
            np.savez_compressed(
                buffer,
                **{
                    a + "_" + r: np.asarray(v)
                    for a, roles in arrays.items()
                    for r, v in roles.items()
                },
            )
            emit("source-image-scores.npz", buffer.getvalue())
        if tensor_hash(backend.encoder.state_dict()) != encoder_hash:
            raise ValueError("encoder changed")
        message({"state": "complete"})


try:
    main()
except BaseException as error:
    try:
        message({"state":"worker_error","type":type(error).__name__,"message":str(error)})
    except BaseException:
        pass
    traceback.print_exc(file=sys.stderr)
    raise
